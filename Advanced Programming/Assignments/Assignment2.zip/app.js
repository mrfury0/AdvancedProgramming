const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const MongoClient = require('mongodb').MongoClient;


var app = express();
app.use(session({secret : "ssshhhh",saveUninitialized : true , resave: true}));
app.use(bodyParser.urlencoded({extended : true}));
app.set("view-engine","ejs");
app.use(express.static(__dirname + '/public'));

var sess;

var url = "mongodb://localhost:27017/product_manager";


MongoClient.connect(url,function(err,db){
  if(err){throw err;}
  var dbo = db.db("product_manager");
  dbo.createCollection("users",function(err,res){
    if(err){throw err;}
    console.log("Collection create");
  });
  dbo.createCollection("products",function(err,res){
    if(err){throw err;}
    console.log("Collection create");
  });
  // Creating admin , run once then comment the code segment
  /*dbo.collection("users").insertOne({ username : "admin" , password : "admin"}, function(err,res){
    if(err){throw err;}
    console.log("1 document inserted");
    db.close();
  });*/
  app.post("/",function(req,res){
    sess = req.session;
    var username = req.body.username;
    var password = req.body.password;
    var query = { username : username, password : password};
    dbo.collection("users").find(query).toArray(function(err,result){
    //  console.log(result);
      console.log(username);

    //  console.log(result.length);
      if(username=="admin" && password=="admin"){
        sess.username=req.body.username;
        sess.password=req.body.password;
        return res.redirect("/dashboard");
      }
      for(i=0;i<result.length;i++){
        if(result[i].username==username && result[i].password == password){
          sess.username=req.body.username;
          sess.password=req.body.password;
          sess.role=result[i].role;

          return res.redirect("/products");
        }
      }

      res.redirect("/");
    });
  });
  app.post("/adduser",function(req,res){
    var name = req.body.name;
    var username = req.body.username;
    var password = req.body.password;
    var role = req.body.role;

    var myobj= {
      name : name,
      username : username,
      password : password,
      role : role
    };
    console.log(role);
    dbo.collection("users").insertOne(myobj,function(err,res){
      if(err){throw err;}
      console.log("1 user added");

    });

    res.redirect("/dashboard");
  })
  app.post("/additem",function(req,res){
    var name = req.body.name;
    var price = req.body.price;
    var desc = req.body.desc;
    var category = req.body.category;
    var image = req.body.image;

    var myobj= {
      name : name,
      desc : desc,
      price : price,
      category : category,
      image : image
    };
    //console.log(role);
    dbo.collection("products").insertOne(myobj,function(err,res){
      if(err){throw err;}
      console.log("1 user added");

    });

    res.redirect("/products");
  })
  app.get("/products",function(req,res){
  //  console.log(sess.role);
    dbo.collection("products").find({}).toArray(function(err, products){
      dbo.collection("users").find({}).toArray(function(err, result){
        res.render("products.ejs", { role : result.role , products : products });
        });
    });

  });
  app.get("/dashboard",function(req,res){
    dbo.collection("users").find({}).toArray(function(err, result){
        //console.log(result);
        res.render("dashboard.ejs", { users : result });
    });
  //  db.close();
  });
  app.get("/",function(req,res){
    res.render("signin.ejs",{error : " "});
  });
  app.route('/addUser')
   	.get(function (req, res) {
  		res.render("addUser.ejs");
  	});
    app.route('/addItem')
     	.get(function (req, res) {
    		res.render("addItem.ejs");
    	});
  app.listen(3000,function(){
    console.log("Server running on port 3000");
  })
});
